import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a string: ");
        String s = sc.nextLine();

        s = s.toLowerCase().replaceAll("[^a-z0-9]", "");

        String reverse = new StringBuilder(s).reverse().toString();

        if (s.equals(reverse)) {
            System.out.println("Valid Palindrome");
        } else {
            System.out.println("Not a Valid Palindrome");
        }
    }
}
