import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a sentence: ");
        String s = sc.nextLine();

        s = s.trim();
        int lastSpace = s.lastIndexOf(' ');
        int length = s.length() - lastSpace - 1;

        System.out.println("Length of last word: " + length);
    }
}
