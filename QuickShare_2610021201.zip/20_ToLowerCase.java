public class Main {
    public static void main(String[] args) {
        String str = "HELLO WORLD";

        String result = str.toLowerCase();

        System.out.println(result);
    }
}
