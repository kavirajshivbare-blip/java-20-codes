import java.util.Scanner;

class Main {
    static class ListNode {
        int val;
        ListNode next;

        ListNode(int val) {
            this.val = val;
            this.next = null;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of nodes: ");
        int n = sc.nextInt();

        ListNode head = null;
        ListNode temp = null;

        System.out.println("Enter binary digits:");

        for (int i = 0; i < n; i++) {
            int value = sc.nextInt();
            ListNode newNode = new ListNode(value);

            if (head == null) {
                head = newNode;
                temp = newNode;
            } else {
                temp.next = newNode;
                temp = newNode;
            }
        }

        int result = 0;
        temp = head;

        while (temp != null) {
            result = result * 2 + temp.val;
            temp = temp.next;
        }

        System.out.println("Decimal value: " + result);
    }
}
