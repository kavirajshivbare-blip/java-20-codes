import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter word: ");
        String word = sc.nextLine();

        System.out.print("Enter character: ");
        char ch = sc.next().charAt(0);

        int index = word.indexOf(ch);

        if (index == -1) {
            System.out.println(word);
        } else {
            String prefix = word.substring(0, index + 1);
            String reverse = new StringBuilder(prefix).reverse().toString();

            System.out.println("Result: " + reverse + word.substring(index + 1));
        }
    }
}
