import java.util.*;

public class Main {
    public static void main(String[] args) {
        String[] word1 = {"ab", "c"};
        String[] word2 = {"a", "bc"};

        String s1 = String.join("", word1);
        String s2 = String.join("", word2);

        if (s1.equals(s2))
            System.out.println("Arrays are Equivalent");
        else
            System.out.println("Arrays are Not Equivalent");
    }
}
