import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a word: ");
        String word = sc.nextLine();
        boolean valid = true;

        for (int i = 0; i < word.length(); i++) {
            if (Character.isUpperCase(word.charAt(i))) {
                if (i != 0) {
                    valid = false;
                    break;
                }
            }
        }

        if (valid)
            System.out.println("Correct Capital Usage");
        else
            System.out.println("Incorrect Capital Usage");
    }
}
